<html lang="en"> <head> <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" charset="UTF-8"></script><script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.js" charset="UTF-8"></script> 

<style type="text/css">
  
  .discount_div_33{
    width: 30%;
    display: inline-block;
  }
  #discount_div_last_minute_20632338{
     width: 40%;
  }
     
</style>
</head>

  <?php function translate($str)
{ return $str;
}
?>
<div id="discount_div_last_minute_20632338"><div class="discount_div_100">
                                <div class="discount_div_33">
                                <input type="hidden" name="discount_last_minute_from_reset_0" id="discount_last_minute_from_reset_20632338_1" value="2"> 
                                <input type="hidden" name="discount_last_minute_to_reset_0" id="discount_last_minute_to_reset_20632338_1" value="1"> 
                                    <select name="discount_from_days[]" style="height: 34px;padding-top: 5px;padding-left: 22px;padding-right: 22px;" id="discount_from_20632338_1" onchange="discount_last_min_function_controller(20632338,1,77777);"> 
                                        <option value="">-Select-</option>  
                                        <option value="1 Day">1 day</option><option value="2 Days">2 days</option><option value="3 Days">3 days</option><option value="4 Days">4 days</option><option value="5 Days">5 days</option><option value="6 Days">6 days</option><option value="7 Days">7 days</option><option value="8 Days">8 days</option><option value="9 Days">9 days</option><option value="10 Days">10 days</option><option value="11 Days">11 days</option><option value="12 Days">12 days</option><option value="13 Days">13 days</option><option value="2 Weeks">2 Weeks</option><option value="3 Weeks">3 Weeks</option><option value="4 Weeks">4 Weeks</option><option value="5 Weeks">5 Weeks</option><option value="6 Weeks">6 Weeks</option><option value="7 Weeks">7 Weeks</option><option value="2 Months">2 Months</option><option value="3 Months">3 Months</option><option value="4 Months">4 Months</option><option value="5 Months">5 Months</option><option value="6 Months">6 Months</option><option value="7 Months">7 Months</option><option value="8 Months">8 Months</option><option value="9 Months">9 Months</option><option value="10 Months">10 Months</option><option value="11 Months">11 Months</option><option value="12 Months">12 Months</option></select></div>
                                        <div class="discount_div_33">
                                            <select name="discount_to_days[]" style="height: 34px;padding-top: 5px;padding-left: 22px;padding-right: 22px;" id="discount_to_20632338_1" onchange="discount_last_min_function_controller(20632338,1,88888);"> 
                                                <option value="">-Select-</option> 
                                                <option value="1 Day">1 day</option> <option value="2 Days">2 days</option><option value="3 Days">3 days</option><option value="4 Days">4 days</option><option value="5 Days">5 days</option><option value="6 Days">6 days</option><option value="7 Days">7 days</option><option value="8 Days">8 days</option><option value="9 Days">9 days</option><option value="10 Days">10 days</option><option value="11 Days">11 days</option><option value="12 Days">12 days</option><option value="13 Days">13 days</option><option value="2 Weeks">2 Weeks</option><option value="3 Weeks">3 Weeks</option><option value="4 Weeks">4 Weeks</option><option value="5 Weeks">5 Weeks</option><option value="6 Weeks">6 Weeks</option><option value="7 Weeks">7 Weeks</option><option value="2 Months">2 Months</option><option value="3 Months">3 Months</option><option value="4 Months">4 Months</option><option value="5 Months">5 Months</option><option value="6 Months">6 Months</option><option value="7 Months">7 Months</option><option value="8 Months">8 Months</option><option value="9 Months">9 Months</option><option value="10 Months">10 Months</option><option value="11 Months">11 Months</option><option value="12 Months">12 Months</option></select></div> 
                                                <div class="discount_div_33" style=" margin-right: 15px;float: right;">
                                                    <span id="currency_symbol" class="input-prefix-curency" style="padding: 8px; margin-top:0;height: 34px;float: right;"><b>%</b></span>
                                                    <select name="discount_last_min[]" style="height: 34px;float: right;padding-right: 12px;padding-top: 5px;padding-left: 22px;padding-right: 22px;" id="discount_last_min_discount_20632338_1"> 
                                                        <option value="">-Select-</option> 
                                                            <option value="1">1</option> 
                                                            
                                                            <option value="2">2</option> 
                                                            
                                                            <option value="3">3</option> 
                                                            
                                                            <option value="4">4</option> 
                                                            
                                                            <option value="5">5</option> 
                                                            
                                                            <option value="6">6</option> 
                                                            
                                                            <option value="7">7</option> 
                                                            
                                                            <option value="8">8</option> 
                                                            
                                                            <option value="9">9</option> 
                                                            
                                                            <option value="10">10</option> 
                                                            
                                                            <option value="11">11</option> 
                                                            
                                                            <option value="12">12</option> 
                                                            
                                                            <option value="13">13</option> 
                                                            
                                                            <option value="14">14</option> 
                                                            
                                                            <option value="15">15</option> 
                                                            
                                                            <option value="16">16</option> 
                                                            
                                                            <option value="17">17</option> 
                                                            
                                                            <option value="18">18</option> 
                                                            
                                                            <option value="19">19</option> 
                                                            
                                                            <option value="20">20</option> 
                                                            
                                                            <option value="21">21</option> 
                                                            
                                                            <option value="22">22</option> 
                                                            
                                                            <option value="23">23</option> 
                                                            
                                                            <option value="24">24</option> 
                                                            
                                                            <option value="25">25</option> 
                                                            
                                                            <option value="26">26</option> 
                                                            
                                                            <option value="27">27</option> 
                                                            
                                                            <option value="28">28</option> 
                                                            
                                                            <option value="29">29</option> 
                                                            
                                                            <option value="30">30</option> 
                                                            
                                                            <option value="31">31</option> 
                                                            
                                                            <option value="32">32</option> 
                                                            
                                                            <option value="33">33</option> 
                                                            
                                                            <option value="34">34</option> 
                                                            
                                                            <option value="35">35</option> 
                                                            
                                                            <option value="36">36</option> 
                                                            
                                                            <option value="37">37</option> 
                                                            
                                                            <option value="38">38</option> 
                                                            
                                                            <option value="39">39</option> 
                                                            
                                                            <option value="40">40</option> 
                                                            
                                                            <option value="41">41</option> 
                                                            
                                                            <option value="42">42</option> 
                                                            
                                                            <option value="43">43</option> 
                                                            
                                                            <option value="44">44</option> 
                                                            
                                                            <option value="45">45</option> 
                                                            
                                                            <option value="46">46</option> 
                                                            
                                                            <option value="47">47</option> 
                                                            
                                                            <option value="48">48</option> 
                                                            
                                                            <option value="49">49</option> 
                                                            
                                                            <option value="50">50</option> 
                                                            
                                                            <option value="51">51</option> 
                                                            
                                                            <option value="52">52</option> 
                                                            
                                                            <option value="53">53</option> 
                                                            
                                                            <option value="54">54</option> 
                                                            
                                                            <option value="55">55</option> 
                                                            
                                                            <option value="56">56</option> 
                                                            
                                                            <option value="57">57</option> 
                                                            
                                                            <option value="58">58</option> 
                                                            
                                                            <option value="59">59</option> 
                                                            
                                                            <option value="60">60</option> 
                                                            
                                                            <option value="61">61</option> 
                                                            
                                                            <option value="62">62</option> 
                                                            
                                                            <option value="63">63</option> 
                                                            
                                                            <option value="64">64</option> 
                                                            
                                                            <option value="65">65</option> 
                                                            
                                                            <option value="66">66</option> 
                                                            
                                                            <option value="67">67</option> 
                                                            
                                                            <option value="68">68</option> 
                                                            
                                                            <option value="69">69</option> 
                                                            
                                                            <option value="70">70</option> 
                                                            
                                                            <option value="71">71</option> 
                                                            
                                                            <option value="72">72</option> 
                                                            
                                                            <option value="73">73</option> 
                                                            
                                                            <option value="74">74</option> 
                                                            
                                                            <option value="75">75</option> 
                                                            
                                                            <option value="76">76</option> 
                                                            
                                                            <option value="77">77</option> 
                                                            
                                                            <option value="78">78</option> 
                                                            
                                                            <option value="79">79</option> 
                                                            
                                                            <option value="80">80</option> 
                                                            
                                                            <option value="81">81</option> 
                                                            
                                                            <option value="82">82</option> 
                                                            
                                                            <option value="83">83</option> 
                                                            
                                                            <option value="84">84</option> 
                                                            
                                                            <option value="85">85</option> 
                                                            
                                                            <option value="86">86</option> 
                                                            
                                                            <option value="87">87</option> 
                                                            
                                                            <option value="88">88</option> 
                                                            
                                                            <option value="89">89</option> 
                                                            
                                                            <option value="90">90</option> 
                                                            
                                                            <option value="91">91</option> 
                                                            
                                                            <option value="92">92</option> 
                                                            
                                                            <option value="93">93</option> 
                                                            
                                                            <option value="94">94</option> 
                                                            
                                                            <option value="95">95</option> 
                                                            
                                                            <option value="96">96</option> 
                                                            
                                                            <option value="97">97</option> 
                                                            
                                                            <option value="98">98</option> 
                                                            
                                                            <option value="99">99</option> 
                                                            
                                                            <option value="100">100</option> 
                                                            </select>
                                                        </div>
                                                    </div></div>
                                                    <input type="hidden" value="1" id="discount_last_minute_counter">
                                                    <p><a href="javascript:void(0)" onclick="add_discount_last_minute(20632338,9999999999999)">+ Add Discount</a></p>

                                                    <script>


function discount_last_min_function_controller(seasionid,count,is_value) {
    var discount_last_minute_from= $('#discount_from_'+seasionid+'_'+count).val();
    var discount_last_minute_to= $('#discount_to_'+seasionid+'_'+count).val();
    discount_last_minute_from = get_value_in_days(discount_last_minute_from);
    discount_last_minute_to = get_value_in_days(discount_last_minute_to);
    var from_day_check=discount_last_minute_from;
    var to_day_check=discount_last_minute_to;

    if(count >1)
    { 
      
      if(discount_last_minute_from > discount_last_minute_to)
      { //alert(1);
        if(is_value=='77777'){
          document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
          /*var reset_from_check=  parseInt(jQuery("#discount_last_minute_from_reset_"+seasionid+"_"+count).val());
          //alert("reset_from_check "+reset_from_check);
          if (reset_from_check !='') {
            document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=reset_from_check
          }else{
            document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=0;
          }  */
        }else{  
          document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
          /*var reset_to_check=parseInt(jQuery("#discount_last_minute_from_reset_"+seasionid+"_"+count).val());
          if (reset_to_check !='') {
            document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=reset_to_check;
          }else{
            document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
          }*/
        }
          return false;         
      }
      var pre_check=count - 1;
      var is_all_okk = 1;
      var is_all_ok = 1;

      var count_each_val = 0;
      var total_length = $("#discount_div_last_minute_"+seasionid+"  select").length;

      $("#discount_div_last_minute_"+seasionid+"  select").each(function() { 

      var id_last_no = this.id.slice(-1);
      var from_day_check_previous=get_value_in_days(jQuery("#discount_from_"+seasionid+"_"+id_last_no).val());
      var to_day_check_previous=get_value_in_days(jQuery("#discount_to_"+seasionid+"_"+id_last_no).val());
      count_each_val++;
      // alert("form => "+from_day_check_previous+"  to => "+ to_day_check_previous+" last No =>"+ id_last_no+" ownid => "+ own_id); 

      if(is_value=='77777'){ 
      
        if(((from_day_check < from_day_check_previous) && (to_day_check > from_day_check_previous)) || ((from_day_check < to_day_check_previous) && (to_day_check > to_day_check_previous)) )
              {                 

                
                  is_all_ok = 0;
                var reset_to_check=parseInt(jQuery("#discount_last_minute_from_reset_"+seasionid+"_"+count).val());
               
                if (reset_to_check !='') {
                document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                }else{
                document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=0;
                 }
                 return false;
              }
        
        if(id_last_no != count){ 
          
                if ((from_day_check >= from_day_check_previous )&& (from_day_check <= to_day_check_previous)) {
                       
                    is_all_ok = 0;
                    var reset_to_check=parseInt(jQuery("#discount_last_minute_from_reset_"+seasionid+"_"+count).val());
                    if (reset_to_check !='') {
                    document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                    }else{
                    document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=0;
                     }
                     return false;
                }
                if((from_day_check == from_day_check_previous) && (isNaN(to_day_check_previous))){
                    is_all_ok = 0;
                    
                    var reset_to_check=parseInt(jQuery("#discount_last_minute_from_reset_"+seasionid+"_"+count).val());
                   
                    if (reset_to_check !='') {
                    document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                    }else{
                    document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=0;
                     }
                     return false;
               }
            }
        
             if(is_all_ok == 1 && count_each_val == total_length){
              
                document.getElementById("discount_last_minute_from_reset_"+seasionid+"_"+count).value=from_day_check;
                //document.getElementById("reset_to_"+check_id).value=to_day_check;
            }
      }
      if(is_value=='88888'){ 
        
        if(!isNaN(from_day_check)){

            if(((from_day_check < from_day_check_previous) && (to_day_check > from_day_check_previous)) || ((from_day_check < to_day_check_previous) && (to_day_check > to_day_check_previous)))
              {

                 is_all_okk = 0;
                var reset_to_check=parseInt(jQuery("#discount_last_minute_to_reset_"+seasionid+"_"+count).val());
                if (reset_to_check !='') {
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                }else{
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
                }
                 return false;
              }

              if(id_last_no != count){
                if ((to_day_check >= from_day_check_previous )&& (to_day_check <= to_day_check_previous)) {
                       
                is_all_okk = 0;
                var reset_to_check=parseInt(jQuery("#discount_last_minute_to_reset_"+seasionid+"_"+count).val());
                if (reset_to_check !='') {
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                }else{
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
                }
                 return false;
                }
              if((to_day_check == from_day_check_previous) && (isNaN(to_day_check_previous))){
                  // alert("not a number");
                  is_all_okk = 0;
                var reset_to_check=parseInt(jQuery("#discount_last_minute_to_reset_"+seasionid+"_"+count).val());
                if (reset_to_check !='') {
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                }else{
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
                }
                 return false;
                }

              }
              if(is_all_okk == 1 && count_each_val == total_length){
                //document.getElementById("reset_from_"+check_id).value=from_day_check;
                document.getElementById("discount_last_minute_to_reset_"+seasionid+"_"+count).value=to_day_check;
              }
          }else{
             document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
          }    
       }
    });

  }
  else{
    if(from_day_check > to_day_check)
    {
      if(is_value=='77777'){
        var reset_to_check=parseInt(jQuery("#discount_last_minute_to_reset_"+seasionid+"_"+count).val());
         /* if (reset_to_check !='') {
          document.getElementById("cancellation_from_select_"+own_id).selectedIndex=reset_to_check;
          }else{
          document.getElementById("cancellation_from_select_"+own_id).selectedIndex=0;
          }*/
          //alert("cancellation_to_select_"+own_id);
          document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
      }else if(is_value=='88888'){
       
        var reset_to_check=parseInt(jQuery("#discount_last_minute_to_reset_"+seasionid+"_"+count).val());
          if (reset_to_check !='') {
          document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=reset_to_check;
          }else{
          document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
          }
      }else{
      }      
    }

    var pre_check=count - 1;
    var is_all_okk = 1;
    var is_all_ok = 1;

    var count_each_val1 = 0;
    var total_length1 = $("#discount_div_last_minute_"+seasionid+"  select").length;

    $("#discount_div_last_minute_"+seasionid+"  select").each(function() { 
    // alert(this.value);   

      var id_last_no = this.id.slice(-1);
      //alert(id_last_no);
      var from_day_check_previous=parseInt(jQuery("#discount_to_"+seasionid+"_"+id_last_no).val());
      var to_day_check_previous=parseInt(jQuery("#discount_to_"+seasionid+"_"+id_last_no).val());
      count_each_val1++;
  // alert("form => "+from_day_check_previous+"  to => "+ to_day_check_previous+" last No =>"+ id_last_no+" ownid => "+ own_id); 

      if(is_value=='77777'){ 
      
        if(((from_day_check < from_day_check_previous) && (to_day_check > from_day_check_previous)) || ((from_day_check < to_day_check_previous) && (to_day_check > to_day_check_previous)) )
              {       
                       
                  is_all_ok = 0;
                var reset_to_check=parseInt(jQuery("#discount_last_minute_from_reset_"+seasionid+"_"+count).val());
               
                if (reset_to_check !='') {
                document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                }else{
                document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=0;
                 }
                 return false;
              }
        if(id_last_no != count){
                  if ((from_day_check >= from_day_check_previous )&& (from_day_check <= to_day_check_previous)) {
                      
                is_all_ok = 0;
                var reset_to_check=parseInt(jQuery("#discount_last_minute_from_reset_"+seasionid+"_"+count).val());
                if (reset_to_check !='') {
                document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                }else{
                document.getElementById("discount_from_"+seasionid+"_"+count).selectedIndex=0;
                 }
                 return false;
                }
            }
        
            if(is_all_ok == 1 && count_each_val1 == total_length1){
              
                document.getElementById("discount_last_minute_from_reset_"+seasionid+"_"+count).value=from_day_check;
                //document.getElementById("reset_to_"+check_id).value=to_day_check;
            }
      }
       if(is_value=='88888'){ 

            if(((from_day_check < from_day_check_previous) && (to_day_check > from_day_check_previous)) || ((from_day_check < to_day_check_previous) && (to_day_check > to_day_check_previous)))
              {

                 is_all_okk = 0;
                var reset_to_check=parseInt(jQuery("#discount_last_minute_to_reset_"+seasionid+"_"+count).val());
                if (reset_to_check !='') {
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                }else{
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
                }
                 return false;
              }

              if(id_last_no != count){
                  if ((to_day_check >= from_day_check_previous )&& (to_day_check <= to_day_check_previous)) {
                       
                is_all_okk = 0;
                var reset_to_check=parseInt(jQuery("#discount_last_minute_to_reset_"+seasionid+"_"+count).val());
                if (reset_to_check !='') {
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=reset_to_check;
                }else{
                document.getElementById("discount_to_"+seasionid+"_"+count).selectedIndex=0;
                }
                 return false;
                }
              }
              // alert(to_day_check+" >= "+ from_day_check_previous+" && "+ to_day_check+" <= "+ to_day_check_previous);
              if(is_all_okk == 1 && count_each_val1 == total_length1){
                //document.getElementById("reset_from_"+check_id).value=from_day_check;
                document.getElementById("discount_last_minute_to_reset_"+seasionid+"_"+count).value=to_day_check;
              }         
       }
    }); 
  }

  
    }


    function add_discount_last_minute(seasonal_id,seasion_count)
{  
    if(seasion_count=='9999999999999'){
      var discount_last_minute_counter= $("#discount_last_minute_counter").val();
      var discount_last_minute_counter_total = parseInt(discount_last_minute_counter) +1;
      $("#discount_last_minute_counter").val(discount_last_minute_counter_total);
    }else{
      var discount_last_minute_counter_check= $("#discount_last_minute_controller_counter").val();
      if(discount_last_minute_counter_check !=''){        
         var discount_last_minute_counter= $("#discount_last_minute_controller_counter").val();
         var discount_last_minute_counter_total = parseInt(discount_last_minute_counter) +1;
         $("#discount_last_minute_controller_counter").val(discount_last_minute_counter_total);
      }else{
        $("#discount_last_minute_controller_counter").val(seasion_count);
        var discount_last_minute_counter_total = seasion_count;      
      }   
    }
    
  n='';
  for(p=2; p<=13; p++){
            n += '<option value="'+p+' Days" >'+p+" <?php echo translate('ppr_Days'); ?>"+'</option>';
          }
          for(p=2; p<=7; p++){
            n += '<option value="'+p+' Weeks" >'+p+" <?php echo translate('ppr_Weeks'); ?>"+'</option>';
          }
          for(p=2; p<=12; p++){
            n += '<option value="'+p+' Months" >'+p+" <?php echo translate('ppr_Months'); ?>"+'</option>';
          }

  $("#discount_div_last_minute_"+seasonal_id).append('<div class="discount_div_100"><div class="discount_div_33"><input type="hidden" name="discount_last_minute_from_reset_0" id="discount_last_minute_from_reset_'+seasonal_id+'_'+discount_last_minute_counter_total+'" value=""> <input type="hidden" name="discount_last_minute_to_reset_0" id="discount_last_minute_to_reset_'+seasonal_id+'_'+discount_last_minute_counter_total+'" value=""> <select name="discount_from_days[]" style="height: 34px;padding-top: 5px;padding-left: 22px;padding-right: 22px;" id="discount_from_'+seasonal_id+'_'+discount_last_minute_counter_total+'" onchange="discount_last_min_function_controller('+seasonal_id+','+discount_last_minute_counter_total+',77777);"  ><option value="">-<?php echo translate("ppr_Select");?>-</option><option value="1 Day">1 <?php echo translate("ppr_Day");?></option> '+n+'</select></div>'+
    '<div class="discount_div_33" >'+
    '<select name="discount_to_days[]" style="height: 34px;padding-top: 5px;padding-left: 22px;padding-right: 22px;" id="discount_to_'+seasonal_id+'_'+discount_last_minute_counter_total+'"  onchange="discount_last_min_function_controller('+seasonal_id+','+discount_last_minute_counter_total+',88888);" ><option value="">-<?php echo translate("ppr_Select");?>-</option><option value="1 Day">1 <?php echo translate("ppr_Day");?></option>'+n+'</select></div>'+'<div class="discount_div_33" style=" margin-right: 15px;float: right;"><span id="currency_symbol"  class="input-prefix-curency" style="padding: 8px; margin-top:0;height: 34px;float: right;"><b>%</b></span><select name="discount_last_min[]" style="height: 34px;float: right;padding-right: 12px;padding-top: 5px;padding-left: 22px;padding-right: 22px;" id="discount_last_min_discount_'+seasonal_id+'_'+discount_last_minute_counter_total+'"><option value="">'+
    '<?php echo '-'.translate("ppr_Select").'-</option> ';
          for($m=1;$m<=100;$m++){
          echo '<option value="'.$m.'">'.$m.'</option>';
          }
           echo '</select</div>';?>');
}

</script>